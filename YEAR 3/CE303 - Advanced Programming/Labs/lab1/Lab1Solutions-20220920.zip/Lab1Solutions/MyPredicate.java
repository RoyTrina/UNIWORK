package Labs.Lab1.AY2021.Solutions;

public interface MyPredicate {

    public boolean apply (int value);

}
