package Labs.Lab1.AY2021.Solutions;

import java.util.function.Predicate;

public class SelectNegative {

    public static void printSelected(int[] list, Predicate<Integer> select){
        for (int element : list)
            if (select.test(element))
                System.out.println(element);
    }

    public static void main (String[] args){
        int[] list = {1, 2, -5, -4, 0, 6};
        printSelected(list, x -> x < 0);
        // ALTERNATIVELY:
        //Predicate<Integer> predicate = x -> x < 0;
        //printSelected(list, predicate);
    }
}
