package Labs.Lab1.AY2021.Solutions;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AdderTest {

    int[] list = {1, 2, -5};

    @Test
    void adder() {
        assertArrayEquals(new int[]{3, 4, -3}, Adder.adder(list, x -> x + 2));
    }
}