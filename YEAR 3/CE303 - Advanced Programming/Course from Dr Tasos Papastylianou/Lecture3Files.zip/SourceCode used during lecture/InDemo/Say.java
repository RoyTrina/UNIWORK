public class Say
{   public static void main( String [] args )
    {   System.out.println( "I'm not shouting!" );
        System.out.println( "I swear!" );
        System.out.println( "I'm actually being very quiet here!" );
        System.out.println();
    }
}
