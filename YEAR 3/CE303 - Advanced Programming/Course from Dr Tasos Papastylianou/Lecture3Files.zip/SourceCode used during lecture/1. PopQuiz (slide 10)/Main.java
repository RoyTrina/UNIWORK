    import java.util.concurrent.CyclicBarrier;

    public class Main
    {
         public static CyclicBarrier cb = new CyclicBarrier( 5, () -> {} );

         public static void main (String [] args)
         {   StringBuilder sb = new StringBuilder("");
             for ( int i = 0; i < 250000; i++ ) sb.append( 'A' );
             for ( int i = 0; i < 250000; i++ ) sb.append( 'G' );
             for ( int i = 0; i < 250000; i++ ) sb.append( 'C' );
             for ( int i = 0; i < 250000; i++ ) sb.append( 'T' );
             String DNA = sb.toString();
             DNAProcessor [] ds = { new DNAProcessor( DNA.substring(      0,  250000 ) ),
                                    new DNAProcessor( DNA.substring( 250000,  500000 ) ),
                                    new DNAProcessor( DNA.substring( 500000,  750000 ) ),
                                    new DNAProcessor( DNA.substring( 750000, 1000000 ) )  };
             Thread [] ts = { new Thread( ds[0] ), new Thread( ds[1] ), new Thread( ds[2] ), new Thread( ds[3] ) };
             System.out.println( DNA );
             for ( Thread t : ts ) { t.start(); }
//           try { Main.cb.await(); } catch (Exception e) {}
             for ( DNAProcessor d : ds ) { System.out.print( d.getPairing() ); }
             System.out.println();
         }
    }

    class DNAProcessor implements Runnable
    {
        private String in;   private StringBuilder out = new StringBuilder("");
        public DNAProcessor ( String in ) { this.in = in; }
        public String getPairing() { return out.toString(); }

        @Override
        public void run()
        {   for (char c : in.toCharArray() )
            { out.append( c == 'A' ? 'T' : c == 'T' ? 'A' : c == 'G' ? 'C' : c == 'C' ? 'G' : 'N' );
//            try { Main.cb.await(); } catch (Exception e) {}
            }
//          try { Main.cb.await(); } catch (Exception e) {}
        }
    }

