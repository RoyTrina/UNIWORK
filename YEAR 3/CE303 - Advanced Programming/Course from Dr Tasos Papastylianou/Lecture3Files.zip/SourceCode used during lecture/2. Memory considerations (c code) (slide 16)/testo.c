# include <stdio.h>
# include <stdlib.h>

struct MyStruct { int a; int b; };

int main( void )
{
 // allocate memory on stack for type int, initialise with value at the same time
    int a = 5;

 // allocate memory on stack for type struct MyStruct, and initialise on the spot
    struct MyStruct b = { .a = 1, .b = 2 };

 // allocate memory on stack for a pointer (of type int) and initialise via malloc
    int * c = malloc( sizeof( int ) );

 // allocate memory on stack for a pointer (of type struct MyStruct), and initialise
    struct MyStruct * d = malloc( sizeof( struct MyStruct ) );

 // Assign values at the (heap) memory locations pointed to by c and d.
    (* c)  = 10;
    d -> a =  3;
    d -> b =  4;

    printf( "a: %d, b: {%d, %d}\n", a, b.a, b.b );

    printf( "c points to heap address %p where value %d is stored\n",
            c, *c
          );

    printf( "d points to heap address %p "
            "where struct with values {%d, %d} is stored\n",
            d, d->a, d->b
          );

    free( c );
    free( d );

    return 0;
}
