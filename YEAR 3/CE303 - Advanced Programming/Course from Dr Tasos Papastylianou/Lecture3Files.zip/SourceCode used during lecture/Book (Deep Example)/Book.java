import java.util.ArrayList; import java.util.List;

public class Book implements Cloneable
{   public String isbn;   public double price;   public String title;   public List< Author > authors;

    public Book( String title, String isbn, double price, List< Author > authors )
    {   this.title = title;   this.isbn = (isbn == null ? "" : isbn);
        this.price = price;   this.authors = new ArrayList<>();
        if (authors != null) { this.authors.addAll( authors ); }  // note: new Array, not reference!
    }

    public Book clone() throws CloneNotSupportedException   // Deep!
    { return new Book( this.title, this.isbn, this.price, this.authors); }

    public String toString() { return "Book [" + title + "]"; }

    public static void main( String[] args ) throws CloneNotSupportedException
    {   Author author1 = new Author( "id1", "name1" );   Author author2 = new Author( "id2", "name2" );
        List< Author > authorsDB = new ArrayList<>();   authorsDB.add( author1 );   authorsDB.add( author2 );

        Book b = new Book( "book1", "", 10, authorsDB );   Book b2 = b.clone();
        b.authors.remove( 0 );   authorsDB.add( new Author( "id3", "name3" ) );

        for( Author A : authorsDB  ) { System.out.print( "  " + A ); } System.out.println();
        for( Author A : b .authors ) { System.out.print( "  " + A ); } System.out.println();
        for( Author A : b2.authors ) { System.out.print( "  " + A ); } System.out.println();
    }
}
