public class Author {
    public String id;
    public String name;
    public Author(String authorId, String name) {
        this.id = authorId;
        this.name = name;
    }

    public String getName(){
        return name;
    }

    public String toString(){
        return "Author[" + id + ", " + name + "]";
    }
}
