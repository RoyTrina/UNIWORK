import com.google.gson.Gson;
import java.io.IOException;

public class GsonExample
{   public static void main ( String[] args ) throws IOException {
        Gson gson = new Gson();
        Author author = new Author("01", "Joyce, James");

     // serialisation
        String authorJson = gson.toJson( author );
        System.out.println( "Json: " + authorJson );

     // round trip: de-serialisation of serialised object
        Author authorCopy = gson.fromJson( authorJson, Author.class );
        System.out.println( "Round trip: " + authorCopy );
    }
}
