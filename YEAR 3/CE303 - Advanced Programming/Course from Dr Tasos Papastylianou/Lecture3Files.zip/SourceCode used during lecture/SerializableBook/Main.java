import java.io.Serializable;         import java.io.IOException;
import java.io.ObjectOutputStream;   import java.io.ObjectInputStream;
import java.io.FileOutputStream;     import java.io.FileInputStream;

class Book implements Serializable {
    String title; String isbn; double price; String author;
    public Book( String title, String isbn, double price, String author ) { this.title = title; this.isbn = isbn; this.price = price; this.author = author; }
    public boolean equals( Book b ) { return this.title.equals(b.title) && this.isbn.equals(b.isbn) && this.price == b.price && this.author.equals(b.author); }
}

public class Main
{
    public static void main( String[] args ) throws IOException, ClassNotFoundException
    {   Book willows = new Book("The Wind in the Willows", "0140621229", 1406, "Ken Grahame");

        try (ObjectOutputStream out = new ObjectOutputStream( new FileOutputStream( "book.dat" ) ) )
        {   out.writeObject(willows);
        } catch (Exception i) { i.printStackTrace(); }

        try (ObjectInputStream in = new ObjectInputStream( new FileInputStream( "book.dat" ) ) )
        {   Book willowsLoaded = (Book) in.readObject();
            if (willowsLoaded.equals(willows)) { System.out.println("(De)Serialization successful"); }
            else { System.out.println( "If you reached this point, deserialization failed." ); }
        } catch (Exception e) { e.printStackTrace(); }
    }
}
