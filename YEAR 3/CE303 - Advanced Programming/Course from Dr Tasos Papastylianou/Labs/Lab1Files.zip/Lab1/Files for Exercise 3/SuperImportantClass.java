package Lab1.Exercise3.Q1;

public class SuperImportantClass
{
    public static int superImportantStaticMethod (int a)
    {
        return a + 1;
    }

    public int superImportantInstanceMethod (int a)
    {
        return a + 2;
    }
}
