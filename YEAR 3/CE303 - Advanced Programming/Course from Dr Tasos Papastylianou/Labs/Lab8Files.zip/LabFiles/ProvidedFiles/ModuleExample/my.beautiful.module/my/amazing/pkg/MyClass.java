package my.amazing.pkg;

public class MyClass
{
    public static int a = 2;
}
