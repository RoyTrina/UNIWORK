module my.incredible.module
{
    requires my.awesome.module;
}
