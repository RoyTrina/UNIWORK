module my.beautiful.module
{
    exports my.amazing.pkg;
}
