module my.awesome.module
{
    exports my.amazing.pkg;
}
