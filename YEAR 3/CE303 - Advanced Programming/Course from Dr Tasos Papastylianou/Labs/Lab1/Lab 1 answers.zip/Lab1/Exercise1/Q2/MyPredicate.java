package Lab1.Exercise1.Q2;

public interface MyPredicate {
    public boolean apply( int value );
}
