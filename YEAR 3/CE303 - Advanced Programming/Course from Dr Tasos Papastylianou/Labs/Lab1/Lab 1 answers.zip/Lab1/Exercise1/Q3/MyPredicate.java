package Lab1.Exercise1.Q3;

public interface MyPredicate {
    public boolean apply( int value );
}
