package Lab1.Exercise1.Q1;

public interface MyPredicate {
    public boolean apply( int value );
}
