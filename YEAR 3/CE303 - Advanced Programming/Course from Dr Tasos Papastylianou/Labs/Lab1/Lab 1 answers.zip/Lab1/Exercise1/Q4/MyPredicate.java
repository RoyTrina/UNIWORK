package Lab1.Exercise1.Q4;

public interface MyPredicate {
    public boolean apply( int value );
}
