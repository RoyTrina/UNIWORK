import java.util.concurrent.CyclicBarrier;

public class CyclicBarrierDemo {
    final static int COUNT = 3; final static int REPEATS = 3;
    final static CyclicBarrier cb =
            new CyclicBarrier(COUNT, () -> System.out.println("All done"));
    static class Task implements Runnable {
        int id;
        Task(int id) { this.id = id; }
        public void run() {
            for (int i = 0; i < REPEATS; i++) {
                System.out.println("Thread " + id + " done");
                try { cb.await(); } catch (Exception e) {}
            }

        }
    }
    public static void main(String[] args) {
        for (int i = 0; i < COUNT; i++)
            new Thread(new Task(i)).start();
    }
}
