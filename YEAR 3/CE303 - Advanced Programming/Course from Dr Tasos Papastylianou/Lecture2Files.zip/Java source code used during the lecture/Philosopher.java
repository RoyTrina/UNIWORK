public abstract class Philosopher implements Runnable {

    //Non-static nested classes (inner classes) have access to other members of the
    //enclosing class, even if they are declared private. Static nested classes do not
    //have access to other members of the enclosing class, unless they're also static.
    static class Fork {
        int holder;
        Fork(int holder) { this.holder = holder; }
    }

    final static int COUNT = 5;

    final static Fork[] forks = new Fork[COUNT];
    static {
        for (int i = 0; i < COUNT; i++)
            forks[i] = new Fork(-1);//initialising a value for holder
    }
    int id;
    Philosopher(int id) { this.id = id; }

    public abstract void run();

    public void takeFork(int i) {
        forks[i].holder = i;
        System.out.println("Philosopher " + id + " takes Fork " + forks[i].holder);
    }
    public void dropFork(int i) {
        forks[i].holder = i;
        System.out.println("Philosopher " + id + " drops Fork " + forks[i].holder);
    }
    public void eat() {
        System.out.println("Philosopher " + id + " is eating...");
    }
}

