package Lectures.Lecture7;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import static java.util.stream.Collectors.joining;

import Lectures.Lecture4.Author;

public class StreamExamples {

    public static void main(String[] args)
    {

        // Creating a List of Integers
        List<Integer> list = Arrays.asList(2, 4, 6, 8, 10, 3, 5, 7, 9, 11);

        int[] oddNumbers =
                IntStream.iterate(1, j -> j + 2).limit(10).toArray();

        int[] evenNumbers = IntStream.iterate(2, j -> j+2).limit(10).toArray();

        int[] multThrees = IntStream
                .iterate(0, i -> i + 3)
                .limit(10)
                .toArray();//returns 0, 3, 6, 9, … 27 [10 items]

        Stream<Double> randoms = Stream.generate(Math::random);
        Double randomNumber = randoms
                .filter(s -> s > 0.5)
                .findAny()
                .get();

        // Creating a list of Prime Numbers
        List<Integer> PrimeNumbers = Arrays.asList(5, 7, 11,13);

        // Creating a list of Odd Numbers
        List<Integer> OddNumbers = Arrays.asList(1, 3, 5);

        // Creating a list of Even Numbers
        List<Integer> EvenNumbers = Arrays.asList(2, 4, 6, 8);

        List<List<Integer>> listOfListofInts =
                Arrays.asList(PrimeNumbers, OddNumbers, EvenNumbers);

        System.out.println("The Structure before flattening is : " +
                listOfListofInts);

        // Using flatMap for transformating and flattening.
        List<Integer> listofInts  = listOfListofInts.stream()
                .flatMap(list2 -> list2.stream())
                .collect(Collectors.toList());

        System.out.println("The Structure after flattening is : " +
                listofInts);

        Stream<Integer> myStream = Stream.of(3,1,4,1,5);
        System.out.print(myStream.map(Object::toString).collect(joining(",")));


        int[] x = IntStream.concat(
                IntStream.range(1,5),
                IntStream.range(1,5))
                .distinct().toArray();

        List<Author> authors = Arrays.
                asList(new Author("1","Mike"),
                        new Author("2", "John"),
                        new Author("2", "Josh"),
                        new Author("2", "Jay"));
        Map<Character, List<Author>> myMap = authors.stream()
                .limit(10)
                .collect(
                        Collectors.groupingBy(a -> a.getName().charAt(0)));

        Stream<Integer> myStream2 = Stream.of(3,1,4,1,5);
        Map<Boolean, List<Integer>> partition
                = myStream2.collect(
                Collectors.partitioningBy(i -> i % 2 == 0));

        for (int i = 0; i < 100; i++) {
            // Using Stream findAny() to return
            // an Optional describing some element
            // of the stream
            Optional<Integer> answer = list.stream().findAny();
            answer = Stream.of(2, 4, 6, 7, 10).findAny();

            // if the stream is empty, an empty
            // Optional is returned.
            if (answer.isPresent()) {
                System.out.println(answer.get());
            } else {
                System.out.println("no value");
            }
        }

        AtomicInteger counter = new AtomicInteger();
        Stream result =
            IntStream.range(0, 5)
                    .mapToObj(e -> counter.incrementAndGet()
                    + ": " + e);
        var res = result.toArray();

    }
}
