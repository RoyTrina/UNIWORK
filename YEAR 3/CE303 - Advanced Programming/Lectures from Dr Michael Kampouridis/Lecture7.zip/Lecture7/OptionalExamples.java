package Lectures.Lecture7;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;

public class OptionalExamples {

    public static List<Optional<Integer>> randomIntOps(int size) {
        List<Optional<Integer>> result = new ArrayList<>();
        Random rand = new Random();
        for (int i = 0; i < size; i++) {
            int r = rand.nextInt(size);
            result.add(i % 3 != 0 ? Optional.of(r) :
                    Optional.empty());
        }
        return result;
    }

    public static int sum(List<Optional<Integer>> opts){
        int result = 0;
        for (Optional<Integer> opt : opts) {
            if (opt.isPresent())
                result += opt.get();
        }
        return result;
    }

    public static void ifPresentOrElse(){
        Optional<Integer> optional = Optional.of(1);
        optional.ifPresentOrElse(x -> System.out.println("Value: " + x), () -> System.out.println("Not present"));

        optional = Optional.empty();
        optional.ifPresentOrElse(x -> System.out.println("Value: " + x), () -> System.out.println("Not present"));
    }

    public static void main (String[] args){
        var list = randomIntOps(10);
        System.out.println(sum(list));
        ifPresentOrElse();
    }
}
