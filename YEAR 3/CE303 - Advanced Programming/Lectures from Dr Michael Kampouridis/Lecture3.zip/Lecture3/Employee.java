package Lectures.Lecture3;

import java.util.ArrayList;

public class Employee implements Cloneable{
    String name;
    String salary;
    ArrayList<Integer> payment = new ArrayList<Integer>();

    public Employee(String name){
        this.name = name;
    }

    public void setSalary(String salary){
        this.salary = salary;
    }

    public static void main(String[] args) throws CloneNotSupportedException {
        Employee employee1 = new Employee("Pete");
//        Employee employee2 = employee1;
        Employee employee2 = (Employee) employee1.clone();
        employee1.payment.add(500);
        employee2.name = "George";
        employee1.setSalary("5000");
        employee2.setSalary("7000");
    }


}
