package Lectures.Lecture3;

import java.util.ArrayList;
import java.util.List;

public class Book implements Cloneable {
    public String isbn;
    public double price;
    public String title;
    public List<Author> authors;

    public Book(String title, String isbn, double price,
                List<Author> authors) {
        this.title = title;
        this.isbn = isbn == null ? "" : isbn;
        this.price = price;
        this.authors = new ArrayList<>();
        if (authors != null)
            this.authors.addAll(authors);
    }

    //For deep cloning, we are creating a new Book object with the constructor.
    public Book clone() throws CloneNotSupportedException {
//        return (Book) super.clone(); //Shallow cloning
        return new Book(
                this.title, this.isbn, this.price,
                this.authors);
    }

    public String toString(){
        return "Book [" + title + "]";
    }

    public static void main(String[] args) throws CloneNotSupportedException {
        Author author1 = new Author("id1", "name1");
        Author author2 = new Author("id2", "name2");
        List<Author> list = new ArrayList<>();
        list.add(author1);
        list.add(author2);

        Book b = new Book("book1", "", 10, list);
        Book b2 = (Book) b.clone();
        b.authors.remove(0);
        list.add(new Author("id3", "name3"));
        System.out.println();
    }

}

