package Lectures.Lecture3;

public class PhilosopherFine extends Philosopher {
    public PhilosopherFine(int id) { super(id); }
    @Override
    public void run() {
        // Deadlock prevention
        int fst = (id == 0 ? id : (id + 1) % COUNT);
        int snd = (id == 0 ? 1 : id);
        synchronized (forks[fst]) {
            takeFork(fst);
            synchronized (forks[snd]) {
                takeFork(snd);
                eat();
                dropFork(snd);
            }
            dropFork(fst);
        }
    }
    public static void main(String[] args){
        Thread[] threads = new Thread[COUNT];
        for (int i = 0; i < COUNT; i++){
            Runnable philosopher = new PhilosopherFine(i);
            threads[i] = new Thread(philosopher);
            threads[i].start();
        }
    }
}