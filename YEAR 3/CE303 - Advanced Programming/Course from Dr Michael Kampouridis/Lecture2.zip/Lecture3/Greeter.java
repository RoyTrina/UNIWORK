package Lectures.Lecture3;

public class Greeter implements Runnable {
    private String greeting;
    private static final int REPETITIONS = 8;
    private static final int DELAY = 100;
    public Greeter(String aGreeting) { greeting = aGreeting; }

    public void run() {
        try {
            for (int i = 1; i <= REPETITIONS; i++) {
                System.out.println(i + ": " + greeting);
                Thread.sleep(DELAY);
            }
        } catch (InterruptedException exception) {}
    }

    public static void main(String[] args) {
        Runnable r1 = new Greeter("Hello, World!");
        Runnable r2 = new Greeter("Goodbye, World!");
        Thread t1 = new Thread(r1);
        Thread t2 = new Thread(r2);
        t1.start();
        t2.start();
    }

}