package Lectures.Lecture3;

public class PhilosopherCoarse extends Philosopher {

    public PhilosopherCoarse(int id) {
        super(id);
    }

    @Override
    public void run() {
        int fst = id;//0
        int snd = (id + 1) % COUNT;//1
        //for Philosopher with ID 0
        synchronized (forks) {
            takeFork(fst);
            takeFork(snd);
            eat();
            dropFork(snd);
            dropFork(fst);
        }
    }

    public static void main(String[] args){
        Thread[] threads = new Thread[COUNT];
        for (int i = 0; i < COUNT; i++){
            Runnable philosopher = new PhilosopherCoarse(i);
            threads[i] = new Thread(philosopher);
            threads[i].start();
        }
    }
}
