package Lectures.Lecture8;

public class Memoisation {
    public static long fibMemo (int n){
        Long[] res = new Long[n + 1];

        return fibMemo(n, res);
    }

    public static long fibMemo (int n, Long[] res){
        if (n == 0 || n == 1)
            return 1;
        if (res[n] == null)
            res[n] = fibMemo(n - 1, res) + fibMemo(n - 2, res);

        return res[n];
    }

    public static void main (String[] args){
        System.out.println(fibMemo(5));
    }
}
