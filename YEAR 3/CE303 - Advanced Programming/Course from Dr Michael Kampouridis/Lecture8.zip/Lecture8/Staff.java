package Lectures.Lecture8;

public class Staff {

    private String name;
    private String employerID;

    public Staff(String name, String employerID){
        this.name = name;
        this.employerID = employerID;
    }

    public String toString() {
        return name + ", " + employerID;
    }

}
