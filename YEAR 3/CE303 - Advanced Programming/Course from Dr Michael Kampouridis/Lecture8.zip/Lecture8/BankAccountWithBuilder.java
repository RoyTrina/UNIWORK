package Lectures.Lecture8;

/** Example from https://dzone.com/articles/design-patterns-the-builder-pattern **/
public class BankAccountWithBuilder {
    private long accountNumber; //This is important, so we'll pass it to the constructor.
    private String owner;
    private String branch;
    private double balance;
    private double interestRate;

    private BankAccountWithBuilder() {
        //Constructor is now private.
    }

    public static class Builder {
        private long accountNumber; //This is important, so we'll pass it to the constructor.
        private String owner;
        private String branch;
        private double balance;
        private double interestRate;

        public Builder(long accountNumber) {
            this.accountNumber = accountNumber;
        }

        public Builder withOwner(String owner){
            this.owner = owner;
            return this;  //By returning the builder each time, we can create a fluent interface (i.e, chains).
        }

        public Builder atBranch(String branch){
            this.branch = branch;
            return this;
        }

        public Builder openingBalance(double balance){
            this.balance = balance;
            return this;
        }

        public Builder atRate(double interestRate){
            this.interestRate = interestRate;
            return this;
        }

        public BankAccountWithBuilder build(){
            //Here we create the actual bank account object, which is always in a fully initialised state
            // when it's returned.
            BankAccountWithBuilder account = new BankAccountWithBuilder();  //Since the Builder is in the
            // BankAccount class, we can invoke its private constructor.
            account.accountNumber = this.accountNumber;
            account.owner = this.owner;
            account.branch = this.branch;
            account.balance = this.balance;
            account.interestRate = this.interestRate;
            return account;
        }
    }
    //Getters and setters omitted for brevity.

    public static void main (String[] args){
        BankAccount bankAccount = new BankAccount(1234, "Marge", "Springfield",
                100, 2.5);

        BankAccountWithBuilder b = new BankAccountWithBuilder.Builder(1234L)
                .withOwner("Marge")
                .atBranch("Springfield")
                .openingBalance(100)
                .atRate(2.5)
                .build();
        System.out.println(b);
    }
}
