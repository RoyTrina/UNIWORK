package Lectures.Lecture8;

import java.util.HashMap;

public class PhoneBook implements Lookup <String, Staff> {

    HashMap<String, Staff> map = new HashMap<>();

    public PhoneBook(){
        Staff staff1 = new Staff("Obi-Wan Kenobi", "1234");
        Staff staff2 = new Staff("Darth Vader", "9999");
        Staff staff3 = new Staff("Luke Skywalker", "1111");
        map.put("Obi-Wan Kenobi", staff1);
        map.put("Darth Vader", staff2);
        map.put("Luke Skywalker", staff3);
    }

    @Override
    public Staff lookup(String name) {
        return map.get(name);
    }

    public static void main (String[] args){
        PhoneBook phoneBook = new PhoneBook();
        Staff retrieved = phoneBook.lookup("Luke Skywalker");
        System.out.println(retrieved);
    }
}
