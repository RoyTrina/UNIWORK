package Lectures.Lecture8;

/** Example from https://dzone.com/articles/design-patterns-the-builder-pattern **/
public class BankAccountSimple {
    private long accountNumber;
    private String owner;
    private double balance;

    public BankAccountSimple(long accountNumber, String owner, double balance) {
        this.accountNumber = accountNumber;
        this.owner = owner;
        this.balance = balance;
    }
    //Getters and setters omitted for brevity.
}
