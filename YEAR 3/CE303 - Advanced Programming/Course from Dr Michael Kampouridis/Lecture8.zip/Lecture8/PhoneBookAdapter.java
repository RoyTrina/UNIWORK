package Lectures.Lecture8;

public class PhoneBookAdapter implements Lookup <String, Staff> {

    private PhoneBook phoneBook;

    public PhoneBookAdapter(){
        phoneBook = new PhoneBook();
    }

    @Override
    public Staff lookup (String name1){
        String[] nameParts = name1.split(",");
        String name2 = nameParts[1].trim() + " " + nameParts[0].trim();

        return phoneBook.lookup(name2);
    }

    public static void main (String[] args){
        PhoneBookAdapter adapter = new PhoneBookAdapter();
        String name1 = "Kenobi, Obi-Wan";
        Staff retrieved = adapter.lookup(name1);
        System.out.println(retrieved);
    }
}
