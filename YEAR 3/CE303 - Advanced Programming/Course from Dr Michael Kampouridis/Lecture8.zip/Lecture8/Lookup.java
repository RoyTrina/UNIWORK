package Lectures.Lecture8;

public interface Lookup <A, B> {
    B lookup (A key);
}
