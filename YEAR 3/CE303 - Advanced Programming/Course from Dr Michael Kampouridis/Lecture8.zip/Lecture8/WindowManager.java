package Lectures.Lecture8;

/** Singleton Pattern example **/
public class WindowManager {
    private static WindowManager windowManager;
    private String info = "Initial info class";

    private WindowManager(){}

    public synchronized static WindowManager getManager(){
        if (windowManager == null)
            windowManager = new WindowManager();

        return windowManager;
    }

    public String getInfo(){
        return info;
    }

    public void setInfo(String info){
        this.info = info;
    }

    public static void main (String[] args){
        WindowManager wm1 = WindowManager.getManager();
        System.out.println(wm1.getInfo());

        WindowManager wm2 = WindowManager.getManager();
        wm2.setInfo("New class info");

        System.out.println(wm1.getInfo());
        System.out.println(wm2.getInfo());

        System.out.println(wm1.equals(wm2));//wm1 and wm2 are equal
    }
}
