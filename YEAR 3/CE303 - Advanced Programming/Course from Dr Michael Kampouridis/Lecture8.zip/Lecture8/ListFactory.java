package Lectures.Lecture8;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ListFactory<A> {
    private Class<? extends List> clazz;

    public ListFactory(Class<? extends List> clazz) {
        this.clazz = clazz;
    }

    //Creates an instance of the List using reflection, hence dynamically defining the type
    public List<A> makeList() {
        List<A> result = null;
        try {
            result = (List<A>)clazz
        .getDeclaredConstructor()
        .newInstance();
        }
        catch (Exception e) { e.printStackTrace(); }

        return result;
    }

    static List<String> populate (String value, ListFactory<String> factory){
        var list = factory.makeList();
        for (var i = 0; i < 3; i++)
            list.add(value);

        return list;
    }

    public static void main (String[] args){
        var list1 = populate("L1", new ListFactory<>(ArrayList.class));
        var list2 = populate("L2", new ListFactory<>(LinkedList.class));
        System.out.println(list1 + ": " + list1.getClass());
        System.out.println(list2 + ": " + list2.getClass());
    }
}

