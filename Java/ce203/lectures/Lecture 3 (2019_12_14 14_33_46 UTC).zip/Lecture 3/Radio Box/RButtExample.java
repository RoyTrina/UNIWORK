import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class RButtExample extends JFrame {

   JRadioButton redB, blueB, greenB;
   Color col = Color.black;

   public RButtExample() {
	         
      add(new JPanel() { 
         public void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.setColor(col);
            g.fillRect(50,50,100,100);
         } 
      }, 
      BorderLayout.CENTER);
      RBHandler rbh = new RBHandler();
      ButtonGroup g = new ButtonGroup();
      redB = new JRadioButton("red", true); 
      redB.addItemListener(  rbh );
      blueB = new JRadioButton("blue", true); 
      blueB.addItemListener(  rbh );
      greenB = new JRadioButton("green", true); 
      greenB.addItemListener(  rbh );

         
      g.add(redB); 
      g.add(blueB); 
      g.add(greenB);
         
      JPanel p = new JPanel();
      p.setLayout(new FlowLayout(FlowLayout.CENTER,10,0));
      
      p.add(redB);    
      p.add(blueB);	
      p.add(greenB);
      
      add(p, BorderLayout.SOUTH);		
      setSize(300, 300);    
      setVisible(true);
   }
   
   public static void main(String args[]) {
   	JFrame myFrame = new RButtExample();
      myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   }   
   
   class RBHandler implements ItemListener {
	     public void itemStateChanged(ItemEvent e) {
           if (e.getSource() == redB){
              col = Color.red;
           }
           else if (e.getSource() == blueB){
              col = Color.blue;
           }
           
           else if (e.getSource() == greenB){
              col = Color.green;
           }

           repaint();
        }  
   }
}
