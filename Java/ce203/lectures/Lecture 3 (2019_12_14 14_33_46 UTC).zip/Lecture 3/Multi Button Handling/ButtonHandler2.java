import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
class ButtonHandler2 implements ActionListener{ 
   
   FilledFrame3 theApp;  
   Color theColor;
   ButtonHandler2(FilledFrame3 app, Color color){ 
	   theApp = app;    
      theColor = color;  
   }
   public void actionPerformed(ActionEvent e){ 
	   theApp.col = theColor;
      theApp.repaint();
    }
}
