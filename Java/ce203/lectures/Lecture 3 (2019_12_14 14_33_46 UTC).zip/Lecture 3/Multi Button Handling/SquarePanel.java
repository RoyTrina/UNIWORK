import java.awt.*;
import javax.swing.*;
class SquarePanel extends JPanel{

   FilledFrame3 theApp;
   SquarePanel( FilledFrame3 app ) { 
  	theApp = app;
   }
   
    public void paintComponent( Graphics g ) { 
      super.paintComponent( g );     
      g.setColor( theApp.col );     
      g.fillRect( 20, 30, 40, 40 );
   }
}

