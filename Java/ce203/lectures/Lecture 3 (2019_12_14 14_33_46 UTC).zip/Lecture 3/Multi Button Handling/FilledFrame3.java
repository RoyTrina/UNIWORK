import java.awt.*;
import javax.swing.*;
public class FilledFrame3 extends JFrame { 
   Color col = Color.red;
   
   public FilledFrame3() { 
      
      createComponents();
   }

   public void createComponents(){

	   JButton butR = new JButton("Red");  
	   JButton butG = new JButton("Green");
	   JButton butB = new JButton("Blue"); 
      // need to add action listeners to buttons
      SquarePanel panel = new SquarePanel(this);
      JPanel butPanel = new JPanel();
      butPanel.add(butR);
      butPanel.add(butG);
      butPanel.add(butB); 
      add(butPanel, BorderLayout.SOUTH);
      add(panel, BorderLayout.CENTER);
      
      butR.addActionListener( new ButtonHandler2(this, Color.red) );
      butG.addActionListener( new ButtonHandler2(this, Color.green) );
      butB.addActionListener( new ButtonHandler2(this, Color.blue) );

      setSize( 200, 200 );
    }
   
   public static void main(String [] args)
   {
      FilledFrame3 frame = new FilledFrame3(); 
	   frame.setTitle("Hello");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	
 	   frame.setVisible(true);

   }
} 
