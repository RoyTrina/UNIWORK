import java.awt.*;
import javax.swing.*;
public class FilledFrame2 extends JFrame { 
   Color col = Color.red;
	
   public FilledFrame2() { 
      JButton but = new JButton("Press me");
      
      but.addActionListener(new ButtonHandler(this));
      
      SquarePanel panel = new SquarePanel(this);
      JPanel buttonPanel = new JPanel();
      buttonPanel.add(but);
      add(buttonPanel, BorderLayout.NORTH);
      add(panel, BorderLayout.CENTER);
      setSize( 200, 200 );
   }
   
   public static void main(String [] args)
   {
      FilledFrame2 frame = new FilledFrame2(); 
	   frame.setTitle("Hello");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	
 	   frame.setVisible(true);

   }
} 
