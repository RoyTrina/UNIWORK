import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
class ButtonHandler implements ActionListener{ 
   FilledFrame2 theApp;

   ButtonHandler( FilledFrame2 app ) { 
      theApp = app; 
   }

   public void actionPerformed(ActionEvent e) { 
      if (theApp.col==Color.blue)         
            theApp.col = Color.red;
      else        
          theApp.col = Color.blue;      
          theApp.repaint();
   }
}
