import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class TextAreaApp extends JFrame {
	private JTextArea myTextArea;

	public TextAreaApp() {
	   super("Text example");
	   myTextArea = new JTextArea(
	 	"This is the first line\n" +
		"and this is the second line", 12, 20);
	   add( myTextArea );
	   setSize( 500, 500 );
	   setVisible( true );
	}
   
   public static void main( String[] args ) {
   TextAreaApp a = new TextAreaApp();
   a.setSize(400,400);
   a.setVisible(true);
   }
 }

