import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class CBoxExample extends JFrame {
   
   boolean filled = false;
   public CBoxExample() {
	   JCheckBox cb = new JCheckBox("fill");
      cb.addItemListener(new CBHandler()); 
	   add(cb, BorderLayout.SOUTH);
	   add(new JPanel() {
	      public void paintComponent(Graphics g) {
		       super.paintComponent(g);
                  if (filled)
	            		g.fillRect(50,50,100,100);
     			      else
	            		g.drawRect(50,50,100,100);
	               }
	  },  BorderLayout.CENTER);
     setSize(300, 300);	
     setVisible(true);
   }
   public static void main(String args[]) {
   	JFrame myFrame = new CBoxExample();
      myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   }   
   
   class CBHandler implements ItemListener {
	   public void itemStateChanged(ItemEvent e) {   
          filled = e.getStateChange()==ItemEvent.SELECTED;  
          repaint();
      }  
   }
}
