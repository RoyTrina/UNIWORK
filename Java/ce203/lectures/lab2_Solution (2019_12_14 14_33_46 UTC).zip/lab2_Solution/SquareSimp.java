import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SquareSimp
{

    public static void main( String[] args )
    {
        FilledFrame frame = new FilledFrame();

        frame.setVisible( true );
    }
}