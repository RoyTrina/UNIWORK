import java.util.*;

abstract class Person implements Comparable {
    protected int regNo;
    abstract void details();
    Person( int a ) { regNo = a; }
    public compareTo(Object obj) { return 1; }
}

class Student extends Person {
    Student( int a ) { super(a); }
    public void details() { System.out.println( "Student " + regNo.toString() ); }
}

class Lecturer extends Person {
    Lecturer( int a ) { }
    public void details() { System.out.println( "Lecturer " + regNo.toString() ); }
}

public class Exam {
    Collection<Person> myList = new ArrayList<Person>();

    public Exam( Person[] myObjects ) {
        for( int i = 0; i<myObjects.length; i++ )
            myList.add( myObjects[i] );
    }

    public void getDetails() {
        Iterator it = myList.iterator();
        while( it.hasNext() ) {
            ((Person)it.next()).details();
        }
    }
}

class Count{
    static Person[] uni = {new Lecturer(1500), new Student(1502), new Student(1501), new Lecturer(1504)};

    public static void main( String[] args ) {
        Exam ex = new Exam( uni );
        ex.getDetails();
    }
}
