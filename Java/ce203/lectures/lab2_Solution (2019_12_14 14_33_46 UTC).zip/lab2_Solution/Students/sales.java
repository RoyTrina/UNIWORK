

import java.util.Scanner;

public class sales extends employee {
    Scanner input = new Scanner(System.in);
    private int numSales;
    public int getNumSales() {
        return numSales;
    }

    public void setNumSales(int numSales) {
        this.numSales = numSales;
    }

    public sales(String Names, int Salary, int Birth) {
        super(Names, Salary, Birth);
        System.out.println("please input sales's number");
        this.numSales = input.nextInt();
    }

    @Override
    public void information() {
        System.out.println("number of sales is "+ numSales );
    }
}
