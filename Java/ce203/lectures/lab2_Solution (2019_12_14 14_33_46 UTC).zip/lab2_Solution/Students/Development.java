
import java.util.Scanner;
public class Development extends employee {
    Scanner input = new Scanner(System.in);
    private String DevelpTrend;
    public String getDevelpTrend() {
        return DevelpTrend;
    }

    public void setDevelpTrend(String develpTrend) {
        DevelpTrend = develpTrend;
    }

    public Development(String Names, int Salary, int Birth) {
        super(Names, Salary, Birth);
        System.out.println("please input development number");
        this.DevelpTrend = input.next();
    }

    @Override
    public void information() {
        System.out.println("trend for " + Names + " is "+ DevelpTrend);

    }
}
