
import java.util.Scanner;
public abstract class employee {
    Scanner input = new Scanner(System.in);
    protected String Names;
    protected int Salary;
    protected int Birth;
    public employee(String Nam, int Sal, int Bir){
        System.out.println("please input names of " + Names);
        this.Names = input.next();
        System.out.println("please input salary of "+ Names);
        this.Salary = input.nextInt();
        System.out.println("please input "+ Names+ "'s birthday");
        this.Birth = input.nextInt();
        System.out.println("name is " + Names);
        System.out.println("gsalary for " + Names + " is " + Salary);
        System.out.println("birthday for " + Names + " is " +Birth);


    }

    public abstract void information();
}
