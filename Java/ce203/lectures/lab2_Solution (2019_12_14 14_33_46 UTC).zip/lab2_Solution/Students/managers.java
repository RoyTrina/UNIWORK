

import java.util.Scanner;

public class managers extends employee {
    Scanner input = new Scanner(System.in);
    private String GradeMan;
    public String getGradeMan() {
        return GradeMan;
    }

    public void setGradeMan(String numMan) {
        this.GradeMan = GradeMan;
    }

    public managers(String Names, int Salary, int Birth) {
        super(Names, Salary, Birth);
        this.Names = "manager";
        System.out.println("please input grade of manager");
        this.GradeMan = input.next();
    }



    @Override
    public void information() {
        System.out.println("grade for " + Names + " is "+ GradeMan );
    }
}
