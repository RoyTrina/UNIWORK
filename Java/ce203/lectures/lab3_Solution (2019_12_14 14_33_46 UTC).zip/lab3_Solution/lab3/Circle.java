package lab3;

import java.awt.*;

/**
 * Created by Owen Daynes on 29/10/2018.
 */
public class Circle extends Shape{

    double radius;

    public Circle(Integer posX, Integer posY, Double radius) {
        super(posX, posY);
        this.radius = radius;
    }

    public Double getArea() {
        return Math.PI * this.radius * this.radius;
    }

    public void draw(Graphics g) {
        g.setColor(Color.RED);
        g.fillOval(this.posX, this.posY, (int)this.radius, (int)this.radius);
    }
}
