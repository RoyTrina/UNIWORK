package lab3;

import java.awt.*;

/**
 * Created by Owen Daynes on 29/10/2018.
 */
public class Square extends Shape {

    Integer sideLength;

    public Square(Integer posX, Integer posY, Integer sideLength) {
        super(posX, posY);
        this.sideLength = sideLength;
    }

    public Integer getArea() {
        return this.sideLength * this.sideLength;
    }

    public void draw(Graphics g) {
        g.setColor(Color.YELLOW);
        g.fillRect(this.posX, this.posY, this.sideLength, this.sideLength);
    }
}
