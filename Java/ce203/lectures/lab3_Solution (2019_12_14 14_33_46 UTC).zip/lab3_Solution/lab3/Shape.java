package lab3;

import java.awt.*;

/**
 * Created by Owen Daynes on 29/10/2018.
 */
public abstract class Shape {

    Integer posX, posY;

    public Shape(Integer posX, Integer posY) {
        this.posX = posX;
        this.posY = posY;
    }

    public abstract void draw(Graphics g);

}
