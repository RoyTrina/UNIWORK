package lab3;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by Owen Daynes on 29/10/2018.
 */
public class DrawCalc extends JFrame{

    private JPanel panelOne;
    private JPanel panelTwo;

    Square square;
    Circle circle;

    JTextField txtField;

    public DrawCalc() {

        // window modification

        setTitle("Drawing shapes");
        setSize(800, 400);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        // instantiate shapes

        square = new Square(10, 10, 50);
        circle = new Circle((this.getWidth()/2) + 10, 10, 50d);

        // create paintable panelOne

        panelOne = new JPanel() {
            public void paintComponent(Graphics g) {
                square.draw(g);
                circle.draw(g);
            }
        };

        // create interactive UI panelTwo

        panelTwo = new JPanel();

        txtField = new JTextField(10);
        JButton btnSetSquare = new JButton("Set square size");
        JButton btnCalcSquareArea = new JButton("Calc square area");
        JButton btnSetCircle = new JButton("Set circle size");
        JButton btnCalcCircleArea = new JButton("Calc circle area");

        panelTwo.add(txtField);
        panelTwo.add(btnSetSquare);
        panelTwo.add(btnCalcSquareArea);
        panelTwo.add(btnSetCircle);
        panelTwo.add(btnCalcCircleArea);

        // add action listeners to buttons

        btnSetSquare.addActionListener(new ButtonHandler(this, 1));
        btnCalcSquareArea.addActionListener(new ButtonHandler(this, 2));
        btnSetCircle.addActionListener(new ButtonHandler(this, 3));
        btnCalcCircleArea.addActionListener(new ButtonHandler(this, 4));

        // add panels to frame

        add(panelOne, BorderLayout.CENTER);
        add(panelTwo, BorderLayout.SOUTH);

    }

    public static void main(String[] args) {
        new DrawCalc().setVisible(true);
    }

}

class ButtonHandler implements ActionListener {

    private DrawCalc theApp;
    private int action;

    public ButtonHandler(DrawCalc theApp, int action) {
        this.theApp = theApp;
        this.action = action;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(this.action == 1) {
            // set square sideLength
            try {
                this.theApp.square.sideLength = Integer.valueOf(theApp.txtField.getText());
                this.theApp.repaint();
            } catch (NumberFormatException ex) {
                System.out.println("Can't cast '" + theApp.txtField.getText() + "' to Integer.");
            }
        }

        if(this.action == 2) {
            // calculate square area
            theApp.txtField.setText(Integer.toString(this.theApp.square.getArea()));
        }

        if(this.action == 3) {
            // set circle radius
            try {
                this.theApp.circle.radius = Double.valueOf(theApp.txtField.getText());
                this.theApp.repaint();
            } catch (NumberFormatException ex) {
                System.out.println("Can't cast '" + theApp.txtField.getText() + "' to Double.");
            }
        }

        if(this.action == 4) {
            // calculate circle area
            theApp.txtField.setText(Double.toString(this.theApp.circle.getArea()));
        }
    }
}
