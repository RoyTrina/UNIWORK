import java.awt.*;
import javax.swing.*;

public class FilledFrame extends JFrame { 
	private JButton button;
	private JLabel label;

	public FilledFrame() {
	  createComponents(); // Helper method.
	  setSize( 300, 300 ); 
	}

	private void createComponents() {
	  button = new JButton("Click me");
	  label = new JLabel("Hello world");
	  JPanel panel = new JPanel();
	  panel.add( button );
	  panel.add( label );
	  add( panel );
	}

	public static void main( String[] args ) { 
	  FilledFrame ff = new FilledFrame();
	  ff.setTitle("A frame with two components");
	  ff.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	
 	  ff.setVisible(true);
	}
     } 
