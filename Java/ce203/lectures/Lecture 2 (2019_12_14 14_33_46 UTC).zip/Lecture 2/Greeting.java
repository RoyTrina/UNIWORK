import javax.swing.*;
import java.awt.*;

public class Greeting { 

public static void draw( Graphics g ) {  // static method can be called without object instantiation
	g.setColor( Color.BLUE );
	g.fillRect( 10, 10, 50, 50 );
}

public static void main(String[] args) {
   JFrame frame = new JFrame(); 
   JPanel component = new JPanel() {
	  public void paintComponent( Graphics graph ) {
		  draw( graph );
     }
   };
   
   frame.add(component);
   frame.setSize( 200, 200 );
	frame.setTitle("Hello");
   frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	
 	frame.setVisible(true);

    
  }
}
