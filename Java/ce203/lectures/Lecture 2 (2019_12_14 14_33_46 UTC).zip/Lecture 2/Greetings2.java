import java.awt.Color;  
import java.awt.Graphics;  
import javax.swing.JComponent;  
import javax.swing.JFrame; 
 
class Greetings2 {  

  public static void draw(Graphics g) {  
      g.setColor(Color.yellow);  
      g.fillRect(30, 30, 100, 100);  
  }  
 
  public static void main(String[] arguments) { 
 
         JComponent com2 = new JComponent(){
            public void paintComponent( Graphics graph ) {
		      draw( graph );
         }
   };

   // create a basic JFrame  
   JFrame frame = new JFrame("JComponent Example");
   JFrame.setDefaultLookAndFeelDecorated(true);  
        
   frame.setSize(300,200);  
   frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
   
   // add the JComponent to main frame  
   frame.add(com2);  
   frame.setVisible(true);  
  }  
}  