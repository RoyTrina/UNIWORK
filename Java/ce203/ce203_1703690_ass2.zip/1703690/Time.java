package assignment2;

import java.util.Timer;
import java.util.TimerTask;

public class Time {

}
