package assignment2;

public class Score {
    private String rule1;
    private String rule2;



}
