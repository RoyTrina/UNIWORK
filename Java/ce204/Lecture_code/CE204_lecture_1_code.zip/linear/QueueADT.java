package linear;

public interface QueueADT {
    public void add (String s);
    public String remove ();
    public boolean isEmpty ();
    public int length ();

}
