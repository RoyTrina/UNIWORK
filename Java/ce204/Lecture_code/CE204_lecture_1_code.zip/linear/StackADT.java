package linear;

public interface StackADT {
    public void push (String s);
    public String pop ();
    public boolean isEmpty ();
    public int length ();
}
