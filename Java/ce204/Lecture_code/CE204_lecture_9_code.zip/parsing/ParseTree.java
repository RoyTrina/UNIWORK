package parsing;

abstract class ParseTree {
    ParseTree left, right;
}

class NumberNode extends ParseTree {
    final int value;
    NumberNode (int value) {
        left = right = null;
        this.value = value;
    }
}

class OperatorNode extends ParseTree {
    final char value;
    OperatorNode (char operator, ParseTree left, ParseTree right) {
        this.value = operator;
        this.left = left;
        this.right = right;
    }
}