package parsing;

public class Parser {
    private Lexer lexer;

    public Parser (Lexer lexer) {
        this.lexer = lexer;
    }

    public ParseTree parse () {
        return parseEXPR();
    }

    private ParseTree parseEXPR () {
        ParseTree left = parseVAL();
        char operator = parseOP();
        ParseTree right = parseVAL();
        return new OperatorNode(operator, left, right);
    }

    private char parseOP () {
        switch (lexer.nextToken().type) {
            case Token.PLUS:   return '+';
            case Token.MINUS:  return '-';
            case Token.TIMES:  return '*';
            case Token.DIVIDE: return '/';
        }
        throw new IllegalArgumentException();
    }

    private ParseTree parseVAL () {
        Token t = lexer.nextToken();
        switch (t.type) {
        case Token.NUMBER:
            return new NumberNode(Integer.parseInt(t.value));
        case Token.LPAREN:
            ParseTree tree = parseEXPR();
            if (lexer.nextToken().type != Token.RPAREN)
                throw new IllegalArgumentException();
            return tree;
        default:
            throw new IllegalArgumentException();
        }
    }

    public static void main (String[] args) {
        ParseTree tree = new Parser (new Lexer("( 1 - 2 ) * ( 4 + 5 )")).parse();
    }
}
