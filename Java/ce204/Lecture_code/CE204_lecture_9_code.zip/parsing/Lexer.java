package parsing;

public class Lexer {

    public Lexer (String s) {
        /* Initialize the lexer to tokenize the given string */
    }

    public Token nextToken() {
        /* Return the next token from the input. */
        return null;
    }

    public Token lookAhead () {
        /* For look-ahead parsers, return the next token without
         * advancing.
         */
        return null;
    }
}
