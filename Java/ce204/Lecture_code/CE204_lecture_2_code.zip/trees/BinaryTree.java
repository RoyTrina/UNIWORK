package trees;

public class BinaryTree {
    private String value;
    private BinaryTree left;
    private BinaryTree right;

    BinaryTree (String value) { this (value, null, null); }

    BinaryTree (String value, BinaryTree left, BinaryTree right) {
        this.value = value;
        this.left  = left;
        this.right = right;
    }

    boolean isLeaf () { return left == null && right == null; }

    BinaryTree leftChild ()  { return left;  }
    BinaryTree rightChild () { return right; }
    String value () { return value; }

    boolean contains (String s) {
        return (value != null && value.equals (s))
                || (left != null && left.contains (s))
                || (right != null && right.contains (s));
    }

    void preOrder () {
        System.out.println(value);
        if (left != null) left.preOrder();
        if (right != null) right.preOrder ();
    }

    void inOrder () {
        if (left != null) left.inOrder ();
        System.out.println(value);
        if (right != null) right.inOrder ();
    }

    void postOrder () {
        if (left != null) left.postOrder();
        if (right != null) right.postOrder ();
        System.out.println(value);
    }
}
