function clearReviews() {
    $("#review").prop('selectedIndex', 0);
}


function itemCounter(){
    document.getElementById("itemCounter").innerHTML = "0";
}
